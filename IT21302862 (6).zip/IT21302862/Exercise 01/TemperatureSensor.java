//Define a remote interface for the temperature sensor that clients can interact with.

interface TemperatureSensor extends java.rmi.Remote
{
	//Returns the current temperature.
	public double getTemperature() throws
		java.rmi.RemoteException;
	
	//Registers a listener that will be notified of temperature changes.
	public void addTemperatureListener
		(TemperatureListener listener )
		throws java.rmi.RemoteException;
	
	//Unregisters a previously registered temperature change listener.
	public void removeTemperatureListener
		(TemperatureListener listener )
		throws java.rmi.RemoteException;
}
