//Define a remote interface objects that want to be notified about temperature changes.

interface TemperatureListener extends java.rmi.Remote
{
	//Called when the temperature changes
	public void temperatureChanged(double temperature) throws 	java.rmi.RemoteException;
}
